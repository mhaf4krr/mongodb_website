const jwt = require("jsonwebtoken")

function auth(req,res,next) {
    const token = req.header('x-auth-token');
    if(!token) {
        return res.status(401).send("Access Denied. No token")
    }

    try {
        
        let decoded_token = jwt.verify(token, "secret");
        req.user = decoded_token
        
        next()

    } catch (error) {
        /* Modified Token Value */
        return res.status(400).send("Invalid Token")
    }
}

exports.auth = auth