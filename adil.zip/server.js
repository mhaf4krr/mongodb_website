const cors = require('cors');
const express = require('express')
const app = express()

app.use(cors());
app.options('*', cors());

app.use(express.static("assets"));

app.engine('html', require('ejs').renderFile);
app.set("view engine","html")

const bodyParser = require('body-parser');
app.use(bodyParser.json());
// for parsing application/xwww-
app.use(bodyParser.urlencoded({ extended: true }));





// SERVER CONFIG WITH RT SOCKETS

const server = require('http').createServer(app);
const io = require('socket.io')(server);
exports.io = io

const website_updater = require("./controllers/website_updater")
const login_register = require("./controllers/login_register")


const master = require("./controllers/master")
const office = require("./controllers/office")
const accounts = require("./controllers/account")

const database = require("./controllers/database").router


const otp_sms = require("./controllers/otp_sms")

io.on('connection', (socket) => {
    console.log("socket connected")
});





// app.use('/updater',website_updater)
app.use('/verify',login_register)
app.use('/db',database)

// app.use("/accounts",accounts)


// app.use("/office",office)
// app.use('/master',master)

app.get("/",(req,res)=>{
    res.sendFile(__dirname+"/assets/main_landing/index.html")
})



 server.listen(3000)
// server.listen();


