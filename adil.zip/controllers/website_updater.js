const express = require('express')
const router = express.Router()

const socket = require('../server')
const io = socket.io

router.get("/",(req,res)=>{
    res.render("update")
})


router.post("/update",(req,res)=>{
    io.emit("update-exclusive",JSON.stringify(req.body))
    res.send("UPDATED")
})


module.exports = router;