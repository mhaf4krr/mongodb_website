const path = require("path")
const { v4: uuidv4 } = require('uuid');


const express = require("express")
const router = express.Router()

/* Acquire MiddleWare for API Authentication */

const authMiddleware = require("../middlewares/auth").auth

const generatePDFTicket = require("./pdf").generatePDFTicket

const sendPurchaseConfirmationEmail = require("./nodemailer").sendPurchaseConfirmationEmail
const singleTicketTemplate = require("./ticket").generateSingleTicket
const sendTicketPurchaseSMS = require("./otp_sms").sendTicketPurchaseSMS



/* MangoDB */
const MongoClient = require('mongodb').MongoClient;


// Connection URL

let mongo_client = null

const url = 'mongodb+srv://hyder:root_linux20@qiblatain-hqkbi.mongodb.net/test?authSource=admin&replicaSet=Qiblatain-shard-0&readPreference=primary&appname=MongoDB%20Compass%20Community&ssl=true';
ObjectID = require('mongodb').ObjectID



/* Reusable Database Object */
let db


async function connect(url) {
      client = await MongoClient.connect(url, {useNewUrlParser: true, useUnifiedTopology: true,});
      const dbName = 'QIBLATAIN';
       db = client.db(dbName)
       return db
}     


connect(url).then((database)=>{
  db = database
  console.log("Database Connected")
})




router.post("/register_external_agent",(req,res)=>{
  let info = req.body
  console.log(info)

  let agent_id = uuidv4()
  agent_id = "QBTAGENTEXT"+agent_id
  let agent_data = req.body
  agent_data.UID = agent_id;
  agent_data._id = agent_id
  
  insertIntoDatabase("AGENTS_EXTERNAL",agent_data)
  .then(()=>{
    res.send("SUCCESS")
  })
  .catch(err=>{
    res.send(err)
  })

})


/* Register Internal Agent */
router.post("/register_internal_agent",(req,res)=>{
  let agent_data = req.body;
  let agent_id = uuidv4()
  agent_id = "QBTAGENTINT"+agent_id
  
  agent_data.UID = agent_id
  agent_data._id = agent_id

  
  insertIntoDatabase("AGENTS_INTERNAL",agent_data).then(()=>{
    res.send("SUCCESS")
  }).catch((err)=> { console.log(err); res.send(err) })
})




/* Purchase a Single Ticket */

router.post("/purchase", async (req,res)=>{
  let passenger_data = req.body;

  let ticketTemplate
 
  try {
    console.log(passenger_data)
    let flight_data = await queryDatabase("FARES",{PNR:passenger_data.PNR})
    flight_data = flight_data[0]
    
    console.log(flight_data)
    
    if (passenger_data.TYPE == "infant"){
  
      /* Seat is not decremented for Infant */
      console.log("Infant")
      passenger_data.PRICE = 1300
      await purchaseTicket(flight_data,passenger_data.PNR,0)
      console.log("Added Infant to purchase")
    }
  
    else {
      await purchaseTicket(flight_data,passenger_data.PNR,1)
    }
  
     let UID = await AddCustomerInformation(passenger_data)
  
     passenger_data.UID = UID
    

     console.log(flight_data)

     ticketTemplate = singleTicketTemplate(flight_data,passenger_data)

     await generatePDFTicket(ticketTemplate,UID)
  
    // sendPurchaseConfirmationEmail(passenger_data.EMAIL,ticketTemplate,UID)
    
     res.send("SUCCESS TICKET PURCHASED")

  } catch (error) {
    console.log(error)
    res.send("FATAL ERROR HAS OCCURED DURING PURCHASE : "+error)
  }


})



router.post("/update",authMiddleware,async (req,res)=>{

try {
  await  updateDatabaseFareEntry(req.body,req.user)
  res.send("UPDATE SUCCESS")
} catch (error) {
  console.log(error)
  res.send("ERROR OCCURED DURING FIELD UPDATION" + error)
}
    
    
})



router.post("/purchase_group",(req,res)=>{
  let PassengerList = req.body

  console.log(PassengerList)
  //First Array Object is genreal information common to all tickets

  if(PassengerList.length <=1){
    res.send("Invalid Details")
  }

  
  let flight_details = PassengerList[0];

  console.log(flight_details)
  /* Remove Flight Information Object */
  PassengerList.shift()

  console.log(PassengerList)

  totalPassengers = PassengerList.length


  purchaseTicket(flight_details.pnr,totalPassengers)
  .then((data)=>{
    AddGroupInformation(PassengerList,flight_details)
  })
  .then((data)=>{
  res.send("SUCCESS")
  })
  .catch((err)=>{
    console.log(err)
    res.send(err)
  })

})



function AddGroupInformation(passengers,flight){
  return new Promise((resolve,reject)=>{
    try {

      let price;

      let query = "INSERT INTO PURCHASE VALUES"
      /* Generate Unique Ticket IDs for all Passenger Tickets */
      
      for(let i=0;i<passengers.length;i++){
        
        let passenger = passengers[i]

        let unique_id = uuidv4()
        unique_id = "QBT-TKT_"+unique_id

        if(passenger.type == "infant"){
          price = 1300
        }

        else {

          price = flight.price

        }

        if(i==0){
          query = query+`("${unique_id}","${passenger.name}","${passenger.email}","${passenger.phone}","${flight.pnr}","${flight.date}","${passenger.type}","${flight.gst}","${flight.issued_to}","${price}")`
        }

        else {
          query = query+`,("${unique_id}","${passenger.name}","${passenger.email}","${passenger.phone}","${flight.pnr}","${flight.date}","${passenger.type}","${flight.gst}","${flight.issued_to}","${price}")`
        }


      }

      query=query+";"

      
      connection.query(query,function(err,results,fields){
        if(err){
          console.log(err)
          reject("ERROR AT GROUP INFO ADD")
        }
  
        else resolve("SUCCESS")
      })
    } catch (error) {
      reject("ERROR AT GROUP INFO ADD")
    }
  })
}



function AddCustomerInformation(passenger_info){
  return new Promise((resolve,reject)=>{
    try {

      let unique_id = uuidv4()
      unique_id = "QBT-TKT_"+unique_id
      passenger_info.UID = unique_id

      insertIntoDatabase("PURCHASE",passenger_info).then(()=>{
        resolve(unique_id)
      })
    }
     catch (error) {
      reject("ERROR AT CUSTOMER INFO ADD")
    }
  })
}


/* Decrements the seats according to PNR */

function purchaseTicket(flight_data,pnr,seats){
  return new Promise((resolve,reject)=>{
    try {
      if(seats == 0){
        /* means infant case -> dont decrement seats*/
        resolve("DONE")
      }

      else {
        update_object = {}
        if(flight_data.SEATS_SOLD + seats > flight_data.TOTAL_SEATS){

          reject(`ERROR: CANNOT ADD ${seats}, only ${flight_data.TOTAL_SEATS - flight_data.SEATS_SOLD} can be purchased`)
        }



        else {

          if(flight_data.SEATS_SOLD + seats == flight_data.THRESHOLD){
            update_object.$set = {
              SEATS_SOLD:flight_data.SEATS_SOLD+seats,
              VISIBILITY:0
            }

            
          }

          else {
            update_object.$set = {SEATS_SOLD: flight_data.SEATS_SOLD+seats }
          }
         
          
          updateDatabase("FARES",{PNR:pnr},update_object).then(()=>{
            console.log("SUCCESS")
            resolve("SUCCESS")
          })

         
        }
        
      }
    } catch (error) {
      reject("ERROR AT SEAT DECREMENT")
    }
  })
}








async function updateDatabaseFareEntry(updated_info,user){

 let changes = []
 let current_info
 current_info = await queryDatabase("FARES",{PNR:updated_info.PNR})
 current_info = current_info[0]

 
  changes = detectChanges(current_info,updated_info) 


  if(changes.length == 0){
    throw new Error("No change has Occured")
   
  }

  let updated_fields = {}

  changes.forEach((change)=>{
    updated_fields[`${change.FIELD}`] = change.UPDATED_VALUE
  })


  await updateDatabase("FARES",{PNR:updated_info.PNR},{$set:updated_fields})
  console.log("Database Updated")
  await updateChangesLog(changes,user,updated_info.PNR)


}



function updateChangesLog(changes,user,PNR) {

 return new Promise((resolve,reject)=>{

 

  changes.forEach((change)=>{
    change.AGENT_NAME = user.NAME
    change.UID = user.UID
    change.PNR = PNR
    change.TIMESTAMP = new Date()
  })

  console.log(changes)
 
  insertManyIntoDatabase("CHANGE_LOGS",changes).then(()=>{
    resolve("SUCCESS")
  })
  

 })
  
}



function detectChanges(current,updated){
  let fields = Object.keys(updated)
  let changes = []

  for(let i = 0 ;i< fields.length ;i++){
    console.log(current[fields[i]],updated[fields[i]])
    if(current[fields[i]] !== updated[fields[i]]){
      changes.push(
        {
          FIELD:fields[i],
          PREVIOUS_VALUE:current[fields[i]],
          UPDATED_VALUE:updated[fields[i]]
        })
    }
  }
  return changes;

}



/* seachFlight returns entire month data starting from that date */

router.post("/searchFlight", async (req,res)=>{
    let search_data = req.body
    search_data.DATE = {$gte:search_data.DATE}
    

    try {

      
      let collection = db.collection("FARES")
      let result = await collection.aggregate([
        {$match:search_data},
        {$sort:{DATE:1}}
      ])

      result = await result.toArray()

      res.send(JSON.stringify(result))
     
      
      
  } catch (error) {   
      console.log(error)
  }


  
})



router.post("/addVendor",authMiddleware,async (req,res)=>{
  try {
    let data = req.body;
    await addVendor(data)
    res.send("Vendor Added")
  } catch (error) {
    console.log(error)
    res.send(error)
  }
})

async function addVendor(data){
  console.log(data)
  let uid = uuidv4()
  data.UID = uid
  return await insertIntoDatabase("VENDORS",data)

}


/* General Read Query Function */

async function queryDatabase(collection_name,filter){
     
  try {

      
      let collection = db.collection(collection_name)
      let result = await collection.find(filter).toArray()
      
      return  result
      
  } catch (error) {   
      console.log(error)
  }


  
}


async function updateDatabase(collection_name,filter,update){
     
  try {
      let collection = db.collection(collection_name)
      let result = await collection.updateOne(filter,update)
      
      return 
      
  } catch (error) {   
      console.log("Error in Updating: "+ error)
  }
  
}

/* General Update Query Function */


async function insertIntoDatabase(collection_name,document){
     
  try {
      let collection = db.collection(collection_name)
      return await collection.insertOne(document) 
  } catch (error) {   
      console.log(error)
  }

 
  
}



async function insertManyIntoDatabase(collection_name,document){
     
  try {
      let collection = db.collection(collection_name)
      return await collection.insertMany(document) 
  } catch (error) {   
      console.log(error)
  }

 
  
}



exports.insertIntoDatabase = insertIntoDatabase

exports.queryDatabase = queryDatabase

exports.router = router