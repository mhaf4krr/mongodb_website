const otpGenerator = require('otp-generator')
const SendOtp = require('sendotp');
const sendOtp = new SendOtp('319542A2a0w09vl5e4fedffP1');
var http = require("https");

var options = {
    "method": "POST",
    "hostname": "api.msg91.com",
    "port": null,
    "path": "/api/v2/sendsms",
    "headers": {
      "authkey": "$authentication_key",
      "content-type": "application/json"
    }
  };
  

    



     function sendOtpSMS(number){

        //add 91 to number before sending otp
        number = number.toString()
        number = "91" +number
        number = parseInt(number)


        return new Promise((resolve,reject)=>{
            let otp=otpGenerator.generate(
                4, { digits:true,upperCase: false,alphabets:false, specialChars: false });
                
                try {
                    sendOtp.send(number, "Qiblatain", otp , function (error, data) {
                        if(data.type == 'success') {
                            resolve(otp)
                        }
                        if(error){
                            reject(error)
                        }
    
                      
            })
                } catch (error) {
                    reject(err)
                }
    })
}



function sendTicketPurchaseSMS(passenger){
    return new Promise((resolve,reject)=>{
       try {
        var req = http.request(options, function (res) {
            var chunks = [];
          
            res.on("data", function (chunk) {
              chunks.push(chunk);
            });
          
            res.on("end", function () {
              var body = Buffer.concat(chunks);
              console.log(body.toString());
            });
          });
          
          let passenger_msg = `Qiblatain Travels. Hi ${passenger.name} your ticket has been booked, details have been mailed to ${passenger.email}.`

          req.write(JSON.stringify({ sender: 'SOCKET',
            route: '4',
            country: '91',
            sms: 
             [ { message: passenger_msg, to: [ `${passenger.phone}` ] } ] }));
          req.end();

          resolve("SUCCESS")
       } catch (error) {
         reject("ERROR AT SMS SENDING")
       }
    })
}

    exports.sendTicketPurchaseSMS = sendTicketPurchaseSMS
    exports.sendOtpSMS = sendOtpSMS