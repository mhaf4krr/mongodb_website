var pdf = require("pdf-creator-node");
var path = require("path")


function generatePDFTicket(html,uid) {
    var html = html
    var options = {
    format: "A3",
    orientation: "portrait",
    border: "10mm",
    header: {
        height: "45mm",
        contents: '<div style="text-align: center;">Qiblatain Travels Pvt Ltd</div>'
    },
    "footer": {
        "height": "28mm",
        "contents": {
        first: 'Cover page',
        2: 'Second page', // Any page number is working. 1-based index
        default: '<span style="color: #444;">{{page}}</span>/<span>{{pages}}</span>', // fallback value
        last: 'Last Page'
     }
     }
    }

    var document = {
        html: html,
        data:{},
        path: `${path.dirname(__dirname)}/assets/tickets/${uid}.pdf`
    };

    return pdf.create(document, options)
   
}

exports.generatePDFTicket = generatePDFTicket