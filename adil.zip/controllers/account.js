const queryDatabase = require("./database").queryDatabase

const express = require("express")
const router = express.Router()



router.post("/addAccountEntry", async(req,res)=>{
    try {
      let data = req.body;
      await addToAccounts(data)
      res.send("added to accounts")
    } catch (error) {
      console.log(err)
      res.send("Error :"+ err)
    }
  })
  
  
  async function addToAccounts(data){
    let query = `INSERT INTO ACCOUNTS VALUES("${data.vendor_uid}","${data.vendor_name}","${data.pnr}","${data.date}","${data.month}","${data.year}","${data.flight_number}","${data.total_seats}","${data.amount_per_seat}","${data.total_amount}","${data.source}","${data.destination}")`
    return await queryDatabase(query)
  }
  



module.exports = router