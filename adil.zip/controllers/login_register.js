const mailer = require("./nodemailer")
const path = require("path")
const express = require('express')
const router = express.Router()
const jwt = require("jsonwebtoken")
const authMiddleware = require("../middlewares/auth").auth
/* Acquire MiddleWare for API Authentication */


const  queryDatabase = require('./database').queryDatabase

const sms = require("./otp_sms")

const nStore = require("nstore")



let users = nStore.new('data/users.db', function () {
    console.log("OTP DB Loaded")
  });






const bodyParser = require('body-parser');
router.use(bodyParser.json()); 
// for parsing application/xwww-
router.use(bodyParser.urlencoded({ extended: true }));

router.get("/",(req,res)=>{
    res.sendFile(path.dirname(__dirname) + "/assets/login/login.html")
})



router.get("/reg",(req,res)=>{
    res.sendFile(path.dirname(__dirname) + "/assets/register/register.html")
})
// OTP FOR EMAIL GENERATION

router.post("/otp-email-gen",(req,res)=>{
    let user = req.body
    console.log(user)
    let otp = mailer.sendOTPMail(user.email,user.name)
    
    console.log(user.email,otp)

    users.save(`${user.email}`, {otp:otp}, function (err) {
        if (err) { throw err; }
        // The save is finished and written to disk safely
        console.log("saved in nstore")
    });

    res.send("success:otp-mailed")
})




// OTP FOR MOBILE GENERATION

router.post("/otp-phone-gen",(req,res)=>{
    let user = req.body
    console.log(user)
    sms.sendOtpSMS(user.phone).then((otp)=>{
        console.log(otp)

    users.save(user.phone, {otp:otp}, function (err) {
        if (err) { throw err; }
        // The save is finished and written to disk safely
        console.log("saved in nstore")
    });

    res.send("success:otp-mobile-sent")

    }).catch((error) => console.log(error) )
    
    
})

router.post("/otp-verify",(req,res)=>{
    let user = req.body

    let verified = false
    verifyOtp(user.key,user.otp,res)

})



router.post("/register",(req,res)=>{
    console.log(req.body)

   let response = {
       success:true,
       errors : []
   }

   res.send(JSON.stringify(response))
})



function verifyOtp(key,otp,res){
    console.log(key)
    try {
        users.get(key,function(err,doc,key){
             console.log(doc.otp + ":" + otp)
             if(doc.otp == otp) {
                users.remove(key, function (err) {
                    if (err) { console.log(err) }
                   console.log("removed")
                });

                 res.send(true).end()
             }
             
             else res.send(false).end()
        })
        
    } catch (error) {
        console.log("Not Found")
        
    }
}


/* Verify Token  */

router.post("/token",authMiddleware,(req,res)=>{
    res.send(true)
})


/* AGENT LOGIN AUTH API */

router.post('/auth',async(req,res)=>{
    console.log(req.body)
    
    let result = await AuthenticateUser(req.body)
    if(result){
        
        try{
            
            console.log(result)
            
            let user = result
            let token =  generateToken(user)

            if(user.type == "internal" && user.ROLE == "master" ){
                res.header('x-auth-token',token).cookie('x-auth-token',token).sendFile(path.dirname(__dirname) + "/assets/panel/master/index.html")
            }

            else if(user.type == "internal" && user.ROLE == "office"){
                res.header('x-auth-token',token).cookie('x-auth-token',token).sendFile(path.dirname(__dirname) + "/assets/panel/office/issue.html")
            }
            

            else if(user.type == "external"){
                res.header('x-auth-token',token).cookie('x-auth-token',token).render("external",{user:user})
            }
        }
        catch(err){
            console.log(err)
        }

    }

    else res.send("Invalid email or password")
})

    
 async function AuthenticateUser(user){
    try {

        let dbUser;


        let user_internal =  await queryDatabase("AGENTS_INTERNAL",{EMAIL:user.username})
        let user_external = await queryDatabase("AGENTS_EXTERNAL",{ACC_EMAIL:user.username})

        console.log(user_internal,user_external)
       
        if(user_internal.length == 0 && user_external.length == 0){
            console.log("No such Agent")
            return false
        }

         else {

             if(user_internal.length == 0){
                 dbUser = user_external[0]
                 dbUser.type = "external"
             }

             if(user_external.length == 0){
                 dbUser = user_internal[0]
                 dbUser.type = "internal"

             }
           

            if(user.password == dbUser.PASSWORD) {
                console.log("PASSWORDS MATCH")
                return dbUser
            }

            else {
                
                console.log("PASSWORD'S DONT MATCH")
                return false
            }

        }

    } catch (error) {
        
    }
}


function generateToken(user){
    let token = jwt.sign(user,"secret")
               
                return token
}




module.exports = router



/*
Database

username : qiblatai
password : ca^xmA37YS88?Z

*/