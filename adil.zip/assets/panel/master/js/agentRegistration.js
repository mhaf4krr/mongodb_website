﻿


$(document).on('click', '#registerAgent', function () {
 
    var role = (getElmValue("role").toString()).toLowerCase();
    var data = {};
    data = {
        "name":getElmValue("txtFname") + getElmValue("txtLname"),
        "email":getElmValue("txtEmail").toString(),
        "phone":getElmValue("txtphone").toString(),
        "address":getElmValue("txtAddress").toString(),
        "pincode":getElmValue("txtPin").toString(),
        "password":getElmValue("txtPassword").toString(),
        "role": role,
    };

    data = JSON.stringify(data);
    console.log(data);
    var xhr = new XMLHttpRequest();
    xhr.addEventListener("readystatechange", function () {

        if (this.readyState === 1) {

       
            document.getElementById("registerAgent").innerHTML = " <span  class='spinner-border spinner-border-sm'></span>Registering...";
            $("#registerAgent").prop('disabled', true);

        }
        else if (this.readyState === 4) {

            console.log(this.responseText);
            $('form :input').val('');
            document.getElementById("registerAgent").innerHTML = " Register";
            $("#registerAgent").prop('disabled', false);
           
            if (alert('The User has been Registered Successfully..!')) {
            }
            else window.location.reload();


        }

    });
    xhr.open("POST", "http://qiblataintravels.com/db/register_internal_agent");
    xhr.setRequestHeader("content-type", "application/json");
    xhr.setRequestHeader("cache-control", "no-cache");
    xhr.send(data);


});