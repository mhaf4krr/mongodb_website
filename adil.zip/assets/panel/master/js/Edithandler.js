﻿var pnr;
function getCookie(name) {
    var v = document.cookie.match('(^|;) ?' + name + '=([^;]*)(;|$)');
    return v ? v[2] : null;
}

let token=getCookie('x-auth-token')
console.log(token)

async function updateDB(){
    if(!confirm("Are you sure to Update")) return
    let updateBtn = document.querySelector("#updateDetails")
    updateBtn.innerHTML = " <span class='spinner-border spinner-border-sm'></span>Updating...";
    let new_data = {

        DATE : getElmValue("Date"),
        SOURCE : getElmValue("departureFrom"),
        DESTINATION : getElmValue("departureTo"),
        AIRLINES : getElmValue("AirlinesName"),
        FLIGHT : getElmValue("Flight"),
        SEATS : parseInt(getElmValue("Seats")),
        DEPARTURE : getElmValue("DepartureTime"),
        ARRIVAL : getElmValue("ArrivalTime"),
        PURCHASE : parseInt(getElmValue("Purchased")),
        MARKUP : parseInt(getElmValue("MarkUp")),
        PNR : pnr
    }

    let url = window.location.origin

    url = url+"/db/update"

    let options = {
        method:"POST",
        headers : {
            'Content-Type': 'application/json;charset=utf-8',
            'x-auth-token' : token
        },

        body: JSON.stringify(new_data)
    }
    let response = await fetch(url,options)
    let result = await response.text()
    return result
    console.log(result)
	updateBtn.innerHTML = " Updated";
   
}


$(document).on('click', '#updateDetails', function () {
    updateDB()
});

$(document).on('click', '.details', function () {
    pnr = $(this).attr('pnr');
    // alert(pnr);
    var e = document.getElementById("pnr");
    e.value = pnr;
    e.disabled = true;
    var q = "query=SELECT * FROM FARES WHERE PNR=" + "'" + pnr + "'";
    var data = encodeURI(q);
    var request = new XMLHttpRequest();
    request.addEventListener("readystatechange", function () {
        if (this.readyState === 4) {
            var jsonObj = JSON.parse(this.responseText);
            console.log(jsonObj);
            document.getElementById("Date").value = jsonObj[0].DATE;
            document.getElementById("departureFrom").value = jsonObj[0].SOURCE;
            document.getElementById("departureTo").value = jsonObj[0].DESTINATION;
            document.getElementById("Seats").value = jsonObj[0].SEATS;
            document.getElementById("AirlinesName").value = jsonObj[0].AIRLINES;
            document.getElementById("Flight").value = jsonObj[0].FLIGHT;
            document.getElementById("DepartureTime").value = jsonObj[0].DEPARTURE;
            document.getElementById("ArrivalTime").value = jsonObj[0].ARRIVAL;
            document.getElementById("Purchased").value = jsonObj[0].PURCHASE;
            document.getElementById("MarkUp").value = jsonObj[0].MARKUP;

        }
    });

    request.open("POST", "http://qiblataintravels.com/db/query");
    request.setRequestHeader("content-type", "application/x-www-form-urlencoded");
    request.setRequestHeader("cache-control", "no-cache");
    request.send(data);
});
