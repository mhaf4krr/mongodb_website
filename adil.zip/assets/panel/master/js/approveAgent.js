function approveAgent(){
  document.getElementById('dashBoard').innerHTML = '';

  document.getElementById('dashBoard').innerHTML = `<h4 class="mt-4">Aprove Agents:</h4> 
   <button type="button" id="ApproveAgentz" class="btn btn-primary" style="margin:10px" onclick="getAgentList()" > Get Agents </button>               
  <ol class="breadcrumb mb-4">
                          <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                           <li class="breadcrumb-item active">Approve</li>
                       </ol>

                        <div class="card mb-4" style="visibility:visible; font-size:12px";> 
                           <div class="card-header"><i class="fas fa-table mr-1"></i>Approve</div> 

                           <div class="card-body"> 
                               <div class="table-responsive"> 
                                  <table class="table table-bordered table-striped"  width="100%" cellspacing="0" id="results"> 
                                       <thead> 
                                      <tr> 
                                       <th>&nbsp Unique Agent Id</th> 
                                       <th>Account Name</th> 
                                        <th>Account Email</th> 
                                        <th>Account GST</th> 
                                        <th>Account PAN</th> 
                                         <th>Account Address</th> 
                                      
                                       <th>Approve</th> 
                                    
                                       
                                      </tr> 
                                       </thead> 
                                     <tbody id="tbody"> 
                                       </tbody> 
                                   </table> 

                                 <script>
                             $(document).on(\keyup\, \#myInput\, function () {
                                  var value = $(this).val().toLowerCase();
                                  $("#results > tbody > tr").filter(function () {
                                      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                                  });
                              });
                             </script>

                               </div> 
                           </div>;`;
 
};