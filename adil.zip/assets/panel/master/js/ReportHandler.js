﻿


function  getAgentDetails(val) {
    let q;
    //alert(val);

    //if( val=="Office"){
    //    q = "query=SELECT e.UID uid, e.EMAIL email, e.PHONE phone, e.NAME name,e.TOTAL_AMOUNT total, p. FROM AGENTS_EXTERNAL e, PURCHASE p ;";

    //}
    //else if(val=="External"){
    //}
    //else{
        
    //}


     q = "query=SELECT * FROM PURCHASE ;";

    //var q = "query=SELECT COUNT( * ) as 'Number' FROM AGENTS_INTERNAL WHERE ROLE='master';";
    let data = encodeURI(q);
    let xhr = new XMLHttpRequest();
    xhr.addEventListener("readystatechange", function () {

        if (this.readyState === 1) {
            alert("on its way");
        }
        else if (this.readyState === 4) {
            console.log(this.responseText);
            var jsonObj = JSON.parse(this.responseText);
            //formatData(jsonObj, 'totalAgents');
        }

    });

    xhr.open("POST", "http://qiblataintravels.com/db/query");
    xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
    xhr.setRequestHeader("cache-control", "no-cache");
    xhr.send(data);

}


function searchAgent(){

    if(document.getElementById('agentOffice').checked && document.getElementById('agentOffice').value == "Office"){
      
        getAgentDetails(document.getElementById('agentOffice').value)      
 }

    else if(document.getElementById('agentExternal').checked && document.getElementById('agentExternal').value=="External"){
    
        getAgentDetails(document.getElementById('agentExternal').value) 
    
    }
    else{
      
        alert("Select type of Agent you want to get Report for...!");
    }
};
    