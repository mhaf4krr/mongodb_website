﻿

$(document).on('click', '#SearchItenary', function(){

    let dataDiv = document.getElementById("dashBoard");
    alert(dataDiv);
dataDiv.innerHTML = '';
dataDiv.innerHTML = '<h1 class="mt-4">Itenary Search</h1>' +
'                       <ol class="breadcrumb mb-4">'+
'                           <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>'+
'                           <li class="breadcrumb-item active">ItenarySearch</li>'+
'                       </ol>'+
'						<div class="mb-4">'+
'                      <label for="birthday">Date:</label>'+
'                            <input type="date" id="Sdate" name="Date">&nbsp&nbsp &nbsp&nbsp'+
'                           <button class="btn btn-primary" id="searchButton" onclick="Dsearch();">'+
'                                Search'+
'                               </button>'+
'                         </div>'+
'                       <div>'+
'						 <div class="card mb-4" style="visibility:visible; font-size:12px";>'+
'                           <div class="card-header"><i class="fas fa-table mr-1"></i>Itenary</div>'+
'                           <div class="card-body">'+
'                               <div class="table-responsive">'+
'                                  <table class="table table-bordered table-striped"  width="100%" cellspacing="0" id="results">'+
'                                       <thead>'+
'                                      <tr>'+
'                                       <th>&nbsp Date </th>'+
'                                       <th>Source</th>'+
'                                        <th>Destination</th>'+
'                                        <th>PNR</th>'+
'                                        <th>Seats</th>'+
'                                         <th>Airline</th>'+
'                                       <th>Flight</th>'+
'                                       <th>Departure</th>'+
'                                       <th>Arrival</th>'+
'                                       <th>Total Cost</th>'+
'                                       <th>Edit</th>'+
'                                      <th>Purchase</th>'+
                                       '<th> View </th>'+ 
'                                      </tr>'+
'                                       </thead>'+
'                                     <tbody id="tbody">'+
'                                       </tbody>'+
'                                   </table>'+
'                               </div>'+
'                           </div>'+
'                           <!-- The Modal -->'+
'   <div class="modal" id="myModal">'+
'    <div class="modal-dialog modal-lg">'+
'      <div class="modal-content">'+
'       <!-- Modal Header -->'+
'        <div class="modal-header">'+
'          <h4 class="modal-title">Edit Inventory</h4>'+
'          <button type="button" class="close" data-dismiss="modal">&times;</button>'+
'        </div>'+
'        <!-- Modal body -->'+
'        <div class="modal-body">'+
'       <form id="InventoryFrom" autocomplete="off" class="form-horizontal" action="/action_page.php">'+
'               <label for="IDate">Date:</label>'+
'                  <input type="text" class="form-control input-sm" placeholder="Date" id="Date">  '+
'                <label for="IPnr">PNR:    </label>'+
'                  <input type="text" class="form-control input-sm" placeholder="PNR" id="pnr">'+
'               <label for="IDeparture">Departure:</label>'+
'                  <input type="text" class="form-control input-sm" placeholder="Departure From" id="departureFrom">'+
'               <label for="IDestination">Destination:</label>'+
'	              <input type="text" class="form-control input-sm" placeholder="Departure to" id="departureTo">'+
'               <label for="ISeats">Seats:</label>'+
'                  <input type="text" class="form-control input-sm" placeholder="Seats" id="Seats">'+
'              <label for="IAirlines">Airlines:</label>'+
'                  <input type="text" class="form-control" placeholder="Airlines Name" id="AirlinesName">'+
'              <label for="IFlight">Flight:</label>'+
'                  <input type="text" class="form-control" placeholder="Flight" id="Flight">'+
'            <label for="IDepratureTimer">Departure Time:</label>'+
'                  <input type="text" class="form-control" placeholder="Departure Time" id="DepartureTime">'+
'            <label for="IArrivalTime">Arrival Time:</label>'+
'                  <input type="text" class="form-control" placeholder="Arrival Time" id="ArrivalTime">'+
'            <label for="IPurchase">Purchased at:</label>'+
'                  <input type="text" class="form-control" placeholder="Purchased @" id="Purchased">'+
'             <label for="IMarkup">Markup:</label>'+
'                  <input type="text" class="form-control" placeholder="Markup" id="MarkUp">'+
'            </form>'+
'        </div>'+
'        <!-- Modal footer -->'+
'        <div class="modal-footer">'+
'          <button type="button" id="updateDetails"  class="btn btn-primary" >Update</button>'+
'        </div>'+
'        '+
'      </div>'+
'    </div>'+
'  </div>'+

'                 </div>'+
'                     <div></div>'+
'               </div>';
});





