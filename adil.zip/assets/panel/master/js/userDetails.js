﻿
function set(jsonObj, p) {
    
    document.getElementById(p).innerHTML = jsonObj[0].Number;
}



function getData(q, divid) {

    //var q = "query=SELECT COUNT( * ) as 'Number' FROM AGENTS_INTERNAL WHERE ROLE='master';";
    var data = encodeURI(q);
    var xhr = new XMLHttpRequest();
    xhr.addEventListener("readystatechange", function () {

        if (this.readyState === 1) {

        }
        else if (this.readyState === 4) {
            console.log(this.responseText);
            var jsonObj = JSON.parse(this.responseText);
            //formatData(jsonObj, 'totalAgents');
            if (divid == 'totalAgents') {
                 var t = jsonObj[0].external + jsonObj[0].internal;
                 $('#totalAgents').text(t);
            }
            else if (divid == 'officeAgents') {
                var t = jsonObj[0].INumber;
                $('#officeAgents').text(t);
            }
            
            else if (divid == 'masterUser') {
                var t = jsonObj[0].ENumber;
                $('#masterUser').text(t);
            }
            
            else if (divid == 'totaltickets') {
                var total = jsonObj[0].Number;
                localStorage.setItem("total", total);
                $('#totaltickets').text(total);
            }
            else if (divid == 'purchasetickets') {
                var purchased = jsonObj[0].Number;
                localStorage.setItem("purchased", purchased);
                $('#purchasetickets').text(purchased);
                document.getElementById('remainTickets').innerHTML = ((localStorage.getItem("total")) - (localStorage.getItem("purchased")));
            }


        }

    });

    xhr.open("POST", "http://qiblataintravels.com/db/query");
    xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
    xhr.setRequestHeader("cache-control", "no-cache");
    xhr.send(data);

     

}




$(document).ready(function () {
    //var q = "query=SELECT COUNT(*)FROM AGENTS_INTERNAL";

    //var q = "query=SELECT COUNT( * ) as 'Number' FROM AGENTS_EXTERNAL;";
    var TotalUsers= "query=SELECT(SELECT COUNT( * ) FROM AGENTS_EXTERNAL) as external,(SELECT COUNT( * ) FROM AGENTS_INTERNAL) as internal;";
    var internalAgents = "query=SELECT COUNT( * ) as 'INumber' FROM AGENTS_INTERNAL WHERE ROLE='office';";
    var master = "query=SELECT COUNT( * ) as 'ENumber' FROM AGENTS_INTERNAL WHERE ROLE='master';";
    var totalTickets = "query=SELECT COUNT( * ) as 'Number' FROM FARES;";
    var purchaseTickets = "query=SELECT COUNT( * ) as 'Number' FROM PURCHASE;";

    //var totalA = "query = SELECT(SELECT COUNT( * ) as 'Internal' FROM   AGENTS_INTERNAL ), (SELECT COUNT( * ) as 'External' FROM AGENTS_EXTERNAL);";
    getData(TotalUsers, 'totalAgents');
    getData(internalAgents, 'officeAgents');
    getData(master, 'masterUser');
    getData(totalTickets, 'totaltickets');
    getData(purchaseTickets, 'purchasetickets'); 
});


