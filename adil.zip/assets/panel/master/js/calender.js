$(document).on('click','#calender', function(){
	
   document.getElementById('dashBoard').innerHTML = '';

     document.getElementById('dashBoard').innerHTML = `<h5 class="mt-4">Calender:</h5> 



  <div style="padding-bottom:10px;">
 <form class="form-inline">

     <div class="form-group"> 
      <label for="From">From:</label>
       <input type="text" class="form-control" id="calenderFrom">
     </div>

     <div class="form-group"> 
      <label for="To">To:</label>
       <input type="text" class="form-control" id="calenderTo">
     </div>

     <div class="form-group"> 
      <label for="Month">Month:</label>
      <select class="form-control" id="Month">
        <option value="January">January</option>
        <option value="February">February</option>
        <option value="March">March</option>
        <option value="April">April</option>
        <option value="May">May</option>
        <option value="June">June</option>
        <option value="July">July</option>
        <option value="August">August</option>
        <option value="September">September</option>
        <option value="October">October</option>
        <option value="November">November</option>
        <option value="December">December</option>
        </select>
   
     </div>

     <div class="form-group"> 
     &nbsp <button type="button" id="getPnrList" class="btn btn-primary"> Get Calender  </button>
   
     </div>
      

    

  </form>

 </div>

  <ol class="breadcrumb mb-4">
                          <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                           <li class="breadcrumb-item active">Calender</li>
                       </ol>

                        <div class="card mb-4" style="visibility:visible; font-size:12px";> 
                           <div class="card-header"><i class="fas fa-table mr-1"></i>Calender</div> 

                           <div class="card-body"> 
                               <div class="table-responsive"> 
                                 






                               </div> 
                           </div>`;
});