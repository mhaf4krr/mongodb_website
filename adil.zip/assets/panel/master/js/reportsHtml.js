﻿$(document).on('click', '#Approve', function () {

    document.getElementById('dashBoard').innerHTML = '';

    var codeBlock = '<h1 class="mt-4">Reports</h1>' +
'                       <ol class="breadcrumb mb-4">' +
'                           <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>' +
'                           <li class="breadcrumb-item active">Report</li>' +
'                       </ol>' +
'						<div class="mb-4">' +
'                         <label class="custom-control-label" for="SearchA"> Search For:</label>'+
                       '<label class="radio-inline">'+
                       ' &nbsp &nbsp &nbsp<input type="radio" name="Agent" id="agentOffice" value="Office"> Office</label>' +
                        '<label class="radio-inline">'+
                     '   &nbsp <input type="radio" name="Agent" id="agentExternal" value="External">External</label>' +
                     '&nbsp &nbsp<button class="btn btn-primary" id="searchAgent" onclick="searchAgent();">  Search </button>'+
                        '</div>' +
'                       <div>' +
'						 <div class="card mb-4" style="visibility:visible; font-size:12px";>' +
'                           <div class="card-header"><i class="fas fa-table mr-1"></i>Report</div>' +
'                           <div class="card-body">' +
'                               <div class="table-responsive">' +
'                                  <table class="table table-bordered table-striped"  width="100%" cellspacing="0" id="results">' +
'                                       <thead>' +
'                                      <tr>' +
'                                       <th>&nbsp Unique Agent Id</th>' +
'                                       <th>Account Name</th>' +
'                                        <th>Account Email</th>' +
'                                        <th>Account Phone</th>' +
'                                        <th>Contact Person</th>' +
'                                         <th>Amount Paid</th>' +
'                                       <th>Amount Pending</th>' +
'                                       <th>Get Details</th>' +
'                                       '+
'                                      </tr>' +
'                                       </thead>' +
'                                     <tbody id="tbody">' +
'                                       </tbody>' +
'                                   </table>' +

                                ' <script>'+
                            ' $(document).on(\'keyup\', \'#myInput\', function () {'+
                                  'var value = $(this).val().toLowerCase();'+
                                 ' $("#results > tbody > tr").filter(function () {'+
                                      '$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)'+
                               '   });'+
                              '});'+
                            ' </script>'+

'                               </div>' +
'                           </div>';
    

    // document.getElementById("kilo").innerHTML = codeBlock;
    document.getElementById('dashBoard').innerHTML = codeBlock;


   // getAgentDetails();

});
