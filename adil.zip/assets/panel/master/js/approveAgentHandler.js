function getAgentList(){


  var q = "query=SELECT * FROM AGENTS_EXTERNAL WHERE APPROVED='0'";
        var data = encodeURI(q);
        var xhr = new XMLHttpRequest();
        xhr.addEventListener("readystatechange", function () {

            if (this.readyState === 1) {
                document.getElementById("ApproveAgentz").innerHTML = " <span  class='spinner-border spinner-border-sm'></span>Searching...";
            }
            else if (this.readyState === 4) {
                var jsonObj = JSON.parse(this.responseText);
                console.log(jsonObj);
                  
                         for(x in jsonObj){

                      document.getElementById('tbody').innerHTML+=`
                                 
                                  <tr>
                                       <td>`
                                          + jsonObj[x].UID +
                                       `</td><td>`
                                        + jsonObj[x].ACC_NAME+
                                        `</td><td>`
                                        + jsonObj[x].ACC_EMAIL+
                                        `</td><td>` 
                                        + jsonObj[x].GST_NUMBER+
                                        `</td><td>`
                                        + jsonObj[x].PAN_NUMBER+
                                        `</td><td>`
                                        + jsonObj[x].STREET_ADDRESS+
                                         `</td><td> 
                                         <button type="button" class="btn btn-primary approve"  uid="` +jsonObj[x].UID+`"> Approve </button>
                                         </td>

                                   </tr>`
                      

                         }



                    }
                    document.getElementById("ApproveAgentz").innerHTML = "Get Agents";
                
            
            
        });

        xhr.open("POST", "http://qiblataintravels.com/db/query");
        xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
        xhr.setRequestHeader("cache-control", "no-cache");
        xhr.send(data);

}




// Approving The Agent By setting 1 to the database
$(document).on('click', '.approve', function(){

    let AgentId = $(this).attr('uid');

 let q = "query=UPDATE AGENTS_EXTERNAL SET APPROVED  = '1' WHERE UID='"+ AgentId +"';"
        var data = encodeURI(q);
        var xhr = new XMLHttpRequest();
        xhr.addEventListener("readystatechange", function () {

            if (this.readyState === 1) {

               // document.getElementById("ApproveAgentz").innerHTML = " <span  class='spinner-border spinner-border-sm'></span>Searching...";
            }
            else if (this.readyState === 4) {
                var jsonObj = JSON.parse(this.responseText);
                console.log(jsonObj);
                  
                    }

                    //document.getElementById("ApproveAgentz").innerHTML = "Get Agents";
                
            
            
        });

        xhr.open("POST", "http://qiblataintravels.com/db/query");
        xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
        xhr.setRequestHeader("cache-control", "no-cache");
        xhr.send(data);
})