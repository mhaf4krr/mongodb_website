﻿let PassengerCount=1;
let PassengersList = []

function removePassengerFromList(name){
    PassengersList = PassengersList.filter((passenger)=>{
        return passenger.name !=name
    })
}

function ClearValue(div) {
    document.getElementById(div).value = "";
}


$(document).on('click', '#AddPassenger', function () {

    if (getElmValue("titleSelect") && getElmValue("Fname") && getElmValue("Lname")) {

      
        $("#personsTable").css("visibility", "visible");

        var id = "Passenger" + PassengerCount;
        PassengerCount++;
        var radioValue = $("input[name='gender']:checked").val();
        $('#personsTable tr:last').after('<tr id= ' + id + '><td id=' + id + 'Name' + '>' + getElmValue("titleSelect") +' '+  getElmValue("Fname") +' '+ getElmValue("Lname") +' ' + '</td><td id=' + id + 'price' + '>' + localStorage.getItem("price")  + '</td><td id=' + id + 'type' + '>' + radioValue +
            '</td><td><button type="button" data-passenger="${getElmValue("Fname")+" "+getElmValue("Lname")}" class="removeSelf btn btn-danger btn-sm" value="x">x</button></td></tr>');

        let passenger = {
            name:getElmValue("Fname")+" "+getElmValue("Lname"),
            type:radioValue.toLowerCase()
        }

        PassengersList.push(passenger)

        ClearValue("Fname");
        ClearValue("Lname");



    }
    else {
        alert("Provide Details First");
    }


});


$(document).on('click', '.removeSelf', function () {
    let passengerName = $(this).data("passenger");
    console.log(passengerName)
    if (confirm("Are You Sure?")) {
        $(this).closest('tr').remove();
        removePassengerFromList(passengerName);
    
    }


    
});



$(document).ready(function () {
    $("input[name='billTo']").click(function () {
        var rValue = $("input[name='billTo']:checked").val();
        if (rValue == 'Agent') {
            $('#Person').hide();
            $('#AgentDiv').show(); 
           
        }
        else if (rValue == 'Person') {
            $('#AgentDiv').hide();
            $('#Person').show();
            
        }
    });
});



$(document).on('click', '#billingTo', function () {
  
    var radioValue = $("input[name='billTo']:checked").val();
    if (radioValue == 'Agent') {
        $('#Person').hide();
        $('#AgentDiv').show(); 
           
    }
    else if (radioValue == 'Person') {
        $('#AgentDiv').hide();
        $('#Person').show();
            
    }

});

$(document).ready(function () {
    $("#txtAgent").keypress(function () {

        if (getElmValue("email").trim() != '' && getElmValue("ContactNumber").trim() != '' && getElmValue("txtPersonName").trim() != '' || getElmValue("txtAgent").trim() != '') {
            $('#PurchaseTicket').prop('disabled', false);
     
        }
   
    });
});

$(document).ready(function () {
    $("#txtPersonName").keypress(function () {

        if (getElmValue("email").trim() != '' && getElmValue("ContactNumber").trim() != '' && getElmValue("txtPersonName").trim() != '' || getElmValue("txtAgent").trim() != '') {
            $('#PurchaseTicket').prop('disabled', false);

        }

    });
});

$(document).on('click', '#PurchaseTicket', function () {
    var billedto;
    if (getElmValue("txtPersonName").trim() != '') {

        billedto = getElmValue("txtPersonName").trim();

    }

    else {

        billedto = getElmValue("txtAgent").toString();
    }


    var totalpassengerCount = ($("#personsTable tr").length) - 1;

    if (billedto != '' && totalpassengerCount != '') {
      
        if (totalpassengerCount == 1 && $("input[name='billTo']:checked").val() == "Person" ) {
            console.log("person");
            var name = document.getElementById("Passenger1Name").innerText;
            var type = document.getElementById("Passenger1type").innerText;
            type = type.toLowerCase();
            var data = {};
            data = { 
                "name": name,
                "email":getElmValue("email").toString(),
                "phone":getElmValue("ContactNumber").toString(),
                "pnr": localStorage.getItem("PNR"), 
                "date":localStorage.getItem("date"),
                "type": type,
                "gst":"NA",
                "issued_to":billedto,
                "price": localStorage.getItem("price")
                
            };

            data = JSON.stringify(data);
            var xhr = new XMLHttpRequest();
            xhr.addEventListener("readystatechange", function () {

                if (this.readyState === 1) {
                    console.log("the log is" +data);
                    document.getElementById("PurchaseTicket").innerHTML = " <span  class='spinner-border spinner-border-sm'></span>Wait...";
                }
                else if (this.readyState === 4) {

                    console.log(this.responseText);
                    Dsearch();
                    document.getElementById("PurchaseTicket").innerHTML = "Purchase";
                    $("#PurchaseTicket").prop('disabled', false);
                    localStorage.clear();
                    //window.location.replace('issue.html');

                }

            });
            xhr.open("POST", "http://qiblataintravels.com/db/purchase");
            xhr.setRequestHeader("content-type", "application/json");
            xhr.setRequestHeader("cache-control", "no-cache");
            xhr.send(data);


        }

        else if (totalpassengerCount > 1 && $("input[name='billTo']:checked").val() == "Person" ) {

            var gsT =localStorage.getItem("GST");
            alert("GST is" + gsT);

            let flight_info = {
                pnr : localStorage.getItem("PNR"), 
                date : localStorage.getItem("date"),
                gst:"NA",
                issued_to:billedto,
                price: localStorage.getItem("price")
            }

            
            let email = getElmValue("email").toString();
            let phone = getElmValue("ContactNumber").toString();

            PassengersList.forEach((passenger)=>{
                passenger.email = email
                passenger.phone = phone
            })

       let ServerData = []
        ServerData.push(flight_info)

        PassengersList.forEach((passenger)=>{
            ServerData.push(passenger)
        })


        var xhr = new XMLHttpRequest();
        xhr.addEventListener("readystatechange", function () {

            if (this.readyState === 1) {


            }
            else if (this.readyState === 4) {

                console.log(this.responseText);

            }

        });

        let url = window.location.origin
        xhr.open("POST", "http://qiblataintravels.com/db/purchase_group");
        xhr.setRequestHeader("content-type", "application/json");
        xhr.setRequestHeader("cache-control", "no-cache");
        xhr.send(JSON.stringify(ServerData));
        
    }

 else if (totalpassengerCount == 1 && $("input[name='billTo']:checked").val() == "Agent" ) {
        console.log("Agent Selected");
        var name = document.getElementById("Passenger1Name").innerText;
        var type = document.getElementById("Passenger1type").innerText;
        type = type.toLowerCase();
        var data = {};
        data = { 
            "name": name,
            "email":getElmValue("email").toString(),
            "phone":getElmValue("ContactNumber").toString(),
            "pnr": localStorage.getItem("PNR"), 
            "date":localStorage.getItem("date"),
            "type": type,
            "gst":"NA",
            "issued_to":localStorage.getItem("UID"),
            "price": localStorage.getItem("price")
                
        };

        data = JSON.stringify(data);
        var xhr = new XMLHttpRequest();
        xhr.addEventListener("readystatechange", function () {

            if (this.readyState === 1) {
                console.log("the log is" +data);
                document.getElementById("PurchaseTicket").innerHTML = " <span  class='spinner-border spinner-border-sm'></span>Wait...";
            }
            else if (this.readyState === 4) {

                console.log(this.responseText);
                Dsearch();
                document.getElementById("PurchaseTicket").innerHTML = "Purchase";
                $("#PurchaseTicket").prop('disabled', false);
                localStorage.clear();
                //window.location.replace('issue.html');

            }

        });
        xhr.open("POST", "http://qiblataintravels.com/db/purchase");
        xhr.setRequestHeader("content-type", "application/json");
        xhr.setRequestHeader("cache-control", "no-cache");
        xhr.send(data);


    }







}

});