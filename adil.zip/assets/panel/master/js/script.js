
function getElmValue(elm) {

    return document.getElementById(elm).value;

}

function addcomma(data) {
    var d = data.toString();
    return "'" + d + "'"+",";
    
}





var count = 0;
function Dsearch() {
    var xhr = new XMLHttpRequest();
    var months = [ "January", "February", "March", "April", "May", "June", 
           "July", "August", "September", "October", "November", "December" ];
    var a = (document.getElementById("Sdate").value);
    console.log(a)
    var date = a.slice(-1);
    var month = a.slice(5, 7);
    var year = a.slice(2, 4);
    
    let data_to_send = {
        date:date,
        month:month,
        year:year
    }

    if (count == 0) {
        
        xhr.addEventListener("readystatechange", function () {

            if (this.readyState === 1) {
                document.getElementById("searchButton").innerHTML = " <span  class='spinner-border spinner-border-sm'></span>Searching...";
            }
            else if (this.readyState === 4) {
                var jsonObj = JSON.parse(this.responseText);
                console.log(jsonObj);
                    for (x in jsonObj) {
                        var a = (jsonObj[x].PURCHASE);
                        var b = jsonObj[x].MARKUP;
                        var totalPrice = a + b;
                        var pnr = jsonObj[x].PNR;
                        document.getElementById("tbody").innerHTML += "<tr><td class='date'>" +
                        jsonObj[x].DATE + "</td> <td>" + jsonObj[x].SOURCE + "</td><td>" + jsonObj[x].DESTINATION + "</td><td>" + pnr + "</td><td>" + jsonObj[x].SEATS +
                        "</td><td>" + jsonObj[x].AIRLINES + "</td><td>" + jsonObj[x].FLIGHT +
                        "</td><td>" + jsonObj[x].DEPARTURE + "</td> <td>" + jsonObj[x].ARRIVAL +
                        "</td>  <td>" + totalPrice +
                        "</td> <td> <button type='button'  pnr='" + pnr + "'class='details btn btn-info btn-primary' data-toggle='modal' data-target='#myModal' >Edit  </button>" +
                        "</td><td> <button type='button'  date='" + jsonObj[x].DATE + "' price='" + totalPrice + "'  pnr='" + pnr + "'class='purchaseBtn btn btn-info btn-primary' data-toggle='modal' data-target='#PurchaseModal' >Purchase</button>" +
                        "</td><td> <button type='button'  pnr='" + pnr + "'class='viewBtn btn btn-info btn-primary' data-toggle='#' data-target='#' >View</button>" +
                        "</td></tr>";

                    }
                    document.getElementById("searchButton").innerHTML = "Search";
                
            }
            count++;
        });

        let url = window.location.origin
        xhr.open("POST", url+"/db/searchFlight");
        xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
        xhr.setRequestHeader("cache-control", "no-cache");
        xhr.send(JSON.stringify(data_to_send));
    }

    else {

            $("#tbody").remove();
            document.getElementById("searchButton").innerHTML = " <span class='spinner-border spinner-border-sm'></span>Searching...";
            var p = document.getElementById("results");
            var newElm = document.createElement("TBODY");
            newElm.setAttribute('id', 'tbody');
            p.appendChild(newElm);

            var q = "query=SELECT * FROM FARES WHERE DATE=" + "'" + newDate + "'";

            var data = encodeURI(q);
            var xhr = new XMLHttpRequest();
            xhr.addEventListener("readystatechange", function () {
                if (this.readyState === 4) {
                    var jsonObj = JSON.parse(this.responseText);
                    // console.log(jsonObj);
                    for (x in jsonObj) {
                        var a = (jsonObj[x].PURCHASE);
                        var b = jsonObj[x].MARKUP;
                        var totalPrice = a + b;
                        var pnr = jsonObj[x].PNR;
                        document.getElementById("tbody").innerHTML += "<tr><td class='date'>" +
                          jsonObj[x].DATE + "</td> <td>" + jsonObj[x].SOURCE + "</td><td>" + jsonObj[x].DESTINATION + "</td><td>" + pnr + "</td><td>" + jsonObj[x].SEATS +
                        "</td><td>" + jsonObj[x].AIRLINES + "</td><td>" + jsonObj[x].FLIGHT +
                        "</td><td>" + jsonObj[x].DEPARTURE + "</td> <td>" + jsonObj[x].ARRIVAL +
                        "</td>  <td>" + totalPrice +
                         "</td> <td> <button type='button'  pnr='" + pnr + "'class='details btn btn-info btn-sm' data-toggle='modal' data-target='#myModal' >Edit</button>" +
                          "</td><td> <button type='button'  date='" + jsonObj[x].DATE + "' price='" + totalPrice + "'  pnr='" + pnr + "'class='purchaseBtn btn btn-info btn-sm' data-toggle='modal' data-target='#PurchaseModal' >Purchase</button>" +
                        "</td></tr>";
                    }
                    document.getElementById("searchButton").innerHTML = " Search";

                }
                count++;

            });

            xhr.open("POST", "http://qiblataintravels.com/db/query");
            xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
            xhr.setRequestHeader("cache-control", "no-cache");
            xhr.send(data);

        }
}



$(document).on('click', '.purchaseBtn', function () {
    var PNR = $(this).attr('pnr');
    var tp = $(this).attr('price');
    var date = $(this).attr('date');
    localStorage.setItem("PNR", PNR);
    localStorage.setItem("price", tp);
    localStorage.setItem("date", date);
});
