function getElmValue(elm) {

    return document.getElementById(elm).value;
}

function addcomma(data) {
    var d = data.toString();
    return "'" + d + "'"+",";
    
}

$(document).on('click', '.purchase', function () {
    var data = $(this).attr('data');
    var datap = $(this).attr('datap');
    var date = $(this).attr('date');
    localStorage.setItem("data", data);
    localStorage.setItem("datap", datap);
    localStorage.setItem("date",date);
});



function Dsearch(){


   
     document.getElementById("listFares").innerHTML ='';

let source= document.getElementById('txtDeparture').value;
let destination= document.getElementById('txtDestination').value;
let departureDate= document.getElementById('departureDate').value;
let arrivalDate= document.getElementById('returnDate').value;
let adult= document.getElementById('txtadults').value;
let infant= document.getElementById('txtinfants').value;


 if(source==''&& destination==''&& departureDate=='' && adult==''|| infant==''){

    alert("all fields are necessary")
 }




else{


 let depart = source.split("|")[0]
 let dest =   destination.split("|")[0]
 depart = depart.toUpperCase();
 dest = dest.toUpperCase();
 totalSeats = parseInt(infant)+ parseInt(adult);
totalSeats = totalSeats.toString();
 

alert(departureDate);
    let a = departureDate;
    let date = a.slice(4,5);
    let month = a.slice(0, 2);
    let year = a.slice(-2);
    let newDate = date + '/' + month + '/' + year;
    newDate = newDate.toString();
   console.log(newDate)
    


 var q = "query=SELECT * FROM FARES WHERE DATE=" + "'" + newDate  + "' AND SOURCE=" + "'" + depart + "' AND DESTINATION="+ "'"+ dest +"' AND SEATS>"+"'"+ totalSeats +"'" ;
       // var q = "query= BEGIN TRANSACTION [Tran1] BEGIN TRY  SELECT * FROM FARES WHERE DATE=" + "'" + newDate + "'" + "COMMIT TRANSACTION [Tran1] END TRY  BEGIN CATCH ROLLBACK TRANSACTION [Tran1] END CATCH";


        var data = encodeURI(q);
        var xhr = new XMLHttpRequest();
        xhr.addEventListener("readystatechange", function () {

            if (this.readyState === 1) {
                document.getElementById("searchButton").innerHTML = " <span  class='spinner-border spinner-border-sm'></span>Searching...";

            }
            else if (this.readyState === 4) {
                var jsonObj = JSON.parse(this.responseText);
                if (jsonObj == null) {
                     document.getElementById("listFares").innerHTML ="<p> No results Found</p>"
              }
            else{
                let img;
                console.log(jsonObj);
          

                  for (x in jsonObj){
                 
                   if(jsonObj[x].AIRLINES== "GO AIR")
                   {
                         img = "img/G8.png";
                   }
                   else if(jsonObj[x].AIRLINES=="INDIGO"){
                         img = "img/6E.png";
                   }
                   else{
                               img = "img/SG.png";
                   }

                
                    let a = (jsonObj[x].PURCHASE);
                    let b = jsonObj[x].MARKUP;
                    let totalPrice = (a + b).toString();
                    let pnr = jsonObj[x].PNR;
                    let encryptedpnr = CryptoJS.AES.encrypt(pnr, "pnr");

                    let encryptedprice = CryptoJS.AES.encrypt(totalPrice, "tp");
            
                    

                     document.getElementById("listFares").innerHTML += `


                                        <div class="card " style="width: 80%; margin: auto;">
                <div class="container">
                   <div class="row">
                          <div class="col p-3">
                           <img src="`+ img +`"height="40" width="40">
                            <span>`+ jsonObj[x].AIRLINES +`</span> | 
                            <span>`+jsonObj[x].FLIGHT+`</span>
                          <p></p>  <button type="button" class="btn btn-primary btn-sm" data-toggle="collapse" data-target="#details`+x+`"> Details</button>
                            </div>
                          <div class="col p-3">
                            <span style="display: block;">`+jsonObj[x].SOURCE +`</span>
                            <span style="display: block;">`+ jsonObj[x].DEPARTURE +`</span>
                            <span>`+ jsonObj[x].DATE+`</span>
                          </div>
                          <div class="col p-3"> 
                            <span style="display: block;">`+ jsonObj[x].DESTINATION +`</span>
                            <span style="display: block;">`+jsonObj[x].ARRIVAL+`</span>
                            <span>`+jsonObj[x].DATE+`</span></div>
                          <div class="col p-3">
                            <span style="display: block;">`+ totalPrice +` INR</span>
                         
                          </div>
                           <div class="col p-3">
                            <button type="button" data-toggle='modal' data-target='#myModal' class="purchase btn btn-primary" date="`+jsonObj[x].DATE +`" data="`+encryptedpnr+`" datap="`+ encryptedprice+`" > Book </button>
                          </div>
  
                  </div>

<div id="details`+x+`" class="collapse">

<ul class="nav nav-tabs" role="tablist">
    <li class="nav-item">
      <a class="nav-link active" data-toggle="tab" href="#home`+x+`">Fare Details</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-toggle="tab" href="#farepan`+x+`">Fare Rules</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-toggle="tab" href="#baggagepan`+x+`">Baggage Rules</a>
    </li>
  </ul>

  <!-- Tab panes -->
  <div class="tab-content">
    <div id="home`+x+`" class="container tab-pane active"><br>
       <h2>
       Fare Details</h2>
       <span>Basic Fare</span> 4500<br>

       <span>Tax and Fee</span> 900 <br>
       <span>Total Fare</span> 5400
      
    </div>
    <div id="farepan`+x+`" class="container tab-pane fade"><br>
          
<p><b>Cancellation / Date Change / Sector Change / Name Change penalties are as under:</b> </p>
<ul class="listNo">
<li> No - Show Fee:</li> 
    <ul class="sublist"> 
    <li>100% penalty, no refund at all.</li>
    </ul>

<li>Cancellation Fees :</li>

<ul class="sublist">
      <li>100% cancellation charges within 72 hours of the flight departure time.<li>
      <li>Departure within 82 Hrs to 7 days - INR 2000.</li>
      <li>Departure beyond 7 days and more INR 1500.</li>
</ul>

<li> Sector Change Fees :</li>
    <ul class="sublist"> 
        <li>Date / Sector Change not Allowed.
        </li>
    </ul>

<li>Name Change Fees :</li>
   <ul class="sublist">
       <li>Name Change not Allowed.
        </li>
  </ul>


<li>Note: </li>
<ul class="sublist">
<li>
Any cancellation of the ticket will be entertained only till 1900 Hrs. After that, a fresh request is to be raised on the next following date any time before 1900 Hrs. (Cancellation policy will be treated as per the fare rules stated above. Latest / fresh request date will be treated as the actual date of cancellation request.)<li>
<li>
Cancellation Request should follow a phone call (on numbers mentioned in the “Contact Us” field) immediately after raising the request.
<li>
</ul>

</ul>


       
    </div>
    <div id="baggagepan`+x+`" class="container tab-pane fade"><br>
     <h2> Baggage Rules</h2>
     <ul>
        <li> 15 Kgs Check-in</li>
        <li> 07 Kgs Cabin</li>
     </ul>
      
    </div>
  </div>
</div>

</div>

</div>
</div>


 <p></p>
                      `;

                  }

                document.getElementById("searchButton").innerHTML = "Search";
                }
            }
        
        });

        xhr.open("POST", "http://qiblataintravels.com/db/query");
        xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
        xhr.setRequestHeader("cache-control", "no-cache");
        xhr.send(data);

































}
  

}