function Agentreport(){

alert("report")



var q = "query=SELECT * FROM AGENTS_EXTERNAL" ;
       // var q = "query= BEGIN TRANSACTION [Tran1] BEGIN TRY  SELECT * FROM FARES WHERE DATE=" + "'" + newDate + "'" + "COMMIT TRANSACTION [Tran1] END TRY  BEGIN CATCH ROLLBACK TRANSACTION [Tran1] END CATCH";


        var data = encodeURI(q);
        var xhr = new XMLHttpRequest();
        xhr.addEventListener("readystatechange", function () {

            if (this.readyState === 1) {
                document.getElementById("Agentreport").innerHTML = " <span  class='spinner-border spinner-border-sm'></span>Getting...";

            }
            else if (this.readyState === 4)
            	var jsonObj = JSON.parse(this.responseText);
                if (jsonObj == null) {
              
             	 }
            	else{
            	    let img;
            	    console.log(jsonObj);
            	     document.getElementById("Agentreport").innerHTML = "Get Report";
             	   }
            
        
        });

        xhr.open("POST", "http://qiblataintravels.com/db/query");
        xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
        xhr.setRequestHeader("cache-control", "no-cache");
        xhr.send(data);



}