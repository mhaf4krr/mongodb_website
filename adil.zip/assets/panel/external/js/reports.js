function reports(){

 document.getElementById("flightinfo").innerHTML="";

   document.getElementById("flightinfo").innerHTML=` 					
        <h3 style="margin-left:50px;" class="mt-4">Reports</h3>  
                        
 						<div class="mb-4" style="margin-left:50px; z-index=99" >   
                         <label class="label" for="id">  Agent UID: </label> 
                           <label class="label" for="Agent_id"> UID</label> 
                           &nbsp &nbsp <label class="label" for="Account"> Account Name:</label>  
                           <label class="label" for="Account_name"> Abc</label>
                               &nbsp &nbsp <label class="label" for="A_email"> Account Name:</label>  
                           <label class="label" for="Account_email"> </label>  
                            &nbsp &nbsp <label class="label" for="A_phone"> Contact No:</label>  
                           <label class="label" for="Account_phone"> 788988888</label>

                       </div>
                                     <button type="button" class="btn btn-link" id="Agentreport" onclick="Agentreport();">Link</button> 
                      <div>   
 						 <div class="card mb-4" style="visibility:visible; font-size:12px";>   
                            <div class="card-header"><i class="fas fa-table mr-1"></i>Report</div>

                            <div class="card-body">   
                                <div class="table-responsive">   
                                   <table class="table table-bordered table-striped"  width="100%" cellspacing="0" id="results">   
                                        <thead>   
                                       <tr>   
                                        <th onclick="Agentreport();">&nbsp S.No</th>
                                        <th> Booking ID/Invoice No</th>     
                                        <th>Booking Date</th> 
										<th> Sector</th> 
                                        <th> Airlines</th> 
                                         <th>Departure Date	</th>   
                                         <th> PNR</th>   
                                         <th> Passenger Info</th>  
                                         <th>Total Fare</th>  
       									 <th> Payment</th> 
       									 <th> Balance</th> 
       									    

                                       	    
                                       	    
                                          
                                       </tr>   
                                        </thead>   
                                      <tbody id="tbody">   
                                        </tbody>   
                                    </table>   

                                  <script>  
                              $(document).on(\ keyup\ , \ #myInput\ , function () {  
                                   var value = $(this).val().toLowerCase();  
                                   $("#results > tbody > tr").filter(function () {  
                                       $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)  
                                   });  
                               });  
                              </script>  

                                </div>   
                            </div> ; `



}