﻿
var passengerCount = 1;

function encrypt(msg, key){

return CryptoJS.AES.encrypt(msg, key);

}

function decrypt(msg, key){

let r = CryptoJS.AES.decrypt(msg, key);
return r.toString(CryptoJS.enc.Utf8);
}

function namesP(data) {

    return ("passenger" + passengerCount).toString();

}

$(document).on('click', '#PurchaseTicket', function () {



 
  

    var billedto;
    if (getElmValue("txtPersonName").trim() != '') {

        billedto = getElmValue("txtPersonName").trim();

    }

    else {

        billedto = localStorage.getItem("UID");
    }



    var totalpassengerCount = ($("#personsTable tr").length) - 1;


 


    if (billedto != '' && totalpassengerCount != '') {


        if (totalpassengerCount == 1) {

            let datapnr = localStorage.getItem("data");
            let dataprice = localStorage.getItem("datap");
            datapnr = CryptoJS.AES.decrypt(datapnr, "pnr");
             dataprice = CryptoJS.AES.decrypt(dataprice,"tp");

             console.log("the pnr is" + datapnr.toString(CryptoJS.enc.Utf8)  +"the Price is: "+ dataprice.toString(CryptoJS.enc.Utf8));

            var name = document.getElementById("Passenger1Name").innerText;
            var type = document.getElementById("Passenger1type").innerText;
            type = type.toLowerCase();

            
            var data = {};
            data = { 
                "name": name,
                "email":getElmValue("email").toString(),
                "phone":getElmValue("ContactNumber").toString(),
                "pnr": datapnr.toString(CryptoJS.enc.Utf8),
                "date":localStorage.getItem("date"),
                "type": type,
                "gst":"NA",
                "issued_to":billedto,
                "price": dataprice.toString(CryptoJS.enc.Utf8),
                
            };

            data = JSON.stringify(data);
            console.log(data);
            var xhr = new XMLHttpRequest();
            xhr.addEventListener("readystatechange", function () {

                if (this.readyState === 1) {

                    document.getElementById("PurchaseTicket").innerHTML = " <span  class='spinner-border spinner-border-sm'></span>Wait...";
                }
                else if (this.readyState === 4) {

                    console.log(this.responseText);
                    Dsearch();
                    document.getElementById("PurchaseTicket").innerHTML = "Purchase";
                    $("#PurchaseTicket").prop('disabled', false);
                    localStorage.clear();
                    document.getElementById('rem').innerHTML='';
                    document.getElementById('rem').innerHTML=`
                                                    <p> Confirmed! </p>
                                                   <p> Your PNR is:  <strong>`+ datapnr.toString(CryptoJS.enc.Utf8) + `</strong> <p>` +  +``;


                    

                }

            });
            xhr.open("POST", "http://qiblataintravels.com/db/purchase");
            xhr.setRequestHeader("content-type", "application/json");
            xhr.setRequestHeader("cache-control", "no-cache");
            xhr.send(data);


        }

        else if (totalpassengerCount > 1) {

            let flight_info = {
                pnr : datapnr.toString(CryptoJS.enc.Utf8), 
                date : localStorage.getItem("date"),
                gst:localStorage.getItem("GST"),
                issued_to:billedto,
                price: dataprice.toString(CryptoJS.enc.Utf8) 
            }

            
            let email = getElmValue("email").toString();
            let phone = getElmValue("ContactNumber").toString();

        PassengersList.forEach((passenger)=>{
            passenger.email = email
            passenger.phone = phone
        })

        let ServerData = []
        ServerData.push(flight_info)

        PassengersList.forEach((passenger)=>{
            ServerData.push(passenger)
        })


        var xhr = new XMLHttpRequest();
            xhr.addEventListener("readystatechange", function () {

                if (this.readyState === 1) {


                }
                else if (this.readyState === 4) {

                    console.log(this.responseText);

                }

            });

            let url = window.location.origin
            xhr.open("POST", "http://qiblataintravels.com/db/purchase_group");
            xhr.setRequestHeader("content-type", "application/json");
            xhr.setRequestHeader("cache-control", "no-cache");
            xhr.send(JSON.stringify(ServerData));
        
}



    }
});