function profileSection(){



 document.getElementById("flightinfo").innerHTML="";

   document.getElementById("flightinfo").innerHTML=` 

<div class="container">
<b> Account Details </b>
<form >
 <div id="accUid" class="input-group mb-3">
         <div class="input-group-prepend">
         <span class="input-group-text">Account UID:</span>
         </div>
         <input type="text" id="Account_UID" class="form-control" placeholder="Account UID" disabled>
       </div>

        <div id="accName" class="input-group mb-3">
         <div class="input-group-prepend">
         <span class="input-group-text">Name:</span>
         </div>
         <input type="text" id="Account_Name" class="form-control" placeholder="Name" disabled>
       </div>

        <div id="accGST" class="input-group mb-3">
         <div class="input-group-prepend">
         <span class="input-group-text">GST</span>
         </div>
         <input type="text" id="Account_GST" class="form-control" placeholder="GST" disabled>
       </div>

        <div id="accPan" class="input-group mb-3">
         <div class="input-group-prepend">
         <span class="input-group-text">PAN</span>
         </div>
         <input type="text" id="Account_PAN" class="form-control" placeholder="PAN" disabled>
       </div>

        <div id="accEmail" class="input-group mb-3">
         <div class="input-group-prepend">
         <span class="input-group-text"> Email:</span>
         </div>
         <input type="text" id="Account_Email" class="form-control" placeholder="Email" disabled>
       </div>

        <div id="accPhone" class="input-group mb-3">
         <div class="input-group-prepend">
         <span class="input-group-text"> Phone:</span>
         </div>
         <input type="text" id="Account_Phone" class="form-control" placeholder="Phone Number" disabled>
       </div>

       <div id="accAddress" class="input-group mb-3">
         <div class="input-group-prepend">
         <span class="input-group-text"> Address:</span>
         </div>
         <input type="text" id="Account_Address" class="form-control" placeholder="Address" disabled>
       </div>

       <div id="accState" class="input-group mb-3">
         <div class="input-group-prepend">
         <span class="input-group-text"> State:</span>
         </div>
         <input type="text" id="Account_State" class="form-control" placeholder="State" disabled>
       </div>

        <div id="accPasswordChange" class="input-group mb-3">
         <div class="input-group-prepend">
         <span class="input-group-text">Change Password:</span>
         </div>
         <input type="text" id="Account_PasswordChange" class="form-control" placeholder="Change Password">
       </div>

          
        <div id="btn_change" class="input-group mb-3">
         
         <button type="button" id="btn_change_pass" onclick="changePassword();" class="btn btn-primary"> Change </button>
       </div>




</form>
   `;
}

