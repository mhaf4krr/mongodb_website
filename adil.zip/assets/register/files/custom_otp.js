
let otpMailAlreadySent = false;
let otpMobileAlreadySent = false;
let otpSmsSent = false;
let email_otp = document.querySelector("#email_otp")
let mobile_otp = document.querySelector("#mobile_otp")
let otpMailVerified = false;
let otpSmsVerified = false;
let username = document.querySelector("#name")
let email = document.querySelector("#otpEmail")
let phone = document.querySelector("#otpNumber")
let phone_otp_msg = document.querySelector("#mobile_successMsg")
let email_otp_msg = document.querySelector("#email_successMsg")
let phoneBtn = document.querySelector("#mobileSend")
let emailBtn = document.querySelector("#emailSend")


function handlePhnBtn(){
    if(!otpMobileAlreadySent){
        sendMobileOtp()
    }

    else {
        //verify otp
        if(mobile_otp.value == "")
        return
        
        otpVerify(phone.value,mobile_otp.value,"phone")
       
    }
}

function handleEmailBtn(){
    if(!otpMailAlreadySent){
        sendMailOtp()
    } 
    else {
        if(email_otp.value == "")
        return

        otpVerify(email.value,email_otp.value,"email")
    }
}

phoneBtn.addEventListener("click",handlePhnBtn)

emailBtn.addEventListener("click",handleEmailBtn)

function sendMailOtp() {

        let url=window.location.origin+"/verify/otp-email-gen"

        const user = {
            name:username.value,
            email:email.value
        };

       
        
        // request options
        const options = {
            method: 'POST',
            body: JSON.stringify(user),
            headers: {
                'Content-Type': 'application/json'
            }
        }
        
        // send POST request
        fetch(url, options)
            .then(res => res.text())
            .then(res => { console.log(res)
            otpMailSent()
            });
}


function sendMobileOtp(){

    phoneBtn.innerHTML = '<img src="/register/files/loader.svg" class="btnLoader">'

    let url=window.location.origin+"/verify/otp-phone-gen"

    MOBILE = phone.value

    const user = {
        name:username.value,
        phone:phone.value
    };

    // request options
    const options = {
        method: 'POST',
        body: JSON.stringify(user),
        headers: {
            'Content-Type': 'application/json'
        }
    }

    // send POST request
    fetch(url, options)
    .then(res => res.text())
    .then(res => { console.log(res)
    otpMobileSent()
    });
}

function otpVerify(key,otp,type){
    let url=window.location.origin+"/verify/otp-verify"

    const user = {
       
        key:key,
        otp:otp
    };

    console.log(user)
    
    // request options
    const options = {
        method: 'POST',
        body: JSON.stringify(user),
        headers: {
            'Content-Type': 'application/json'
        }
    }
    
    // send POST request
    fetch(url, options)
        .then(res => res.text())
        .then(res => { 
            let verified
            if(res == "true"){
                verified = true
            }
            else verified = false

            switch(type){
                case "phone": if(verified){
                    otpMobileVerificationSuccess()
                    otpVerified.mobile = 1;
                }
                else otpMobileVerificationFailed()
                break;


                case "email":if(verified) {
                    otpMailVerificationSuccess()
                    otpVerified.email = 1;
                }else {
                    otpMailVerificationFailed()
                }
                break;
            }
        });
}


function otpMailSent(){

    EMAIL = email.value

    otpMailAlreadySent = true;
    emailBtn.textContent = "VERIFY"
    email_otp.style.display = "block";
    email.style.display = "none"
    email_otp_msg.textContent = "an email has been send, please use the OTP from the email to proceed."
}


function otpMobileSent(){
    otpMobileAlreadySent = true;
    phoneBtn.textContent = "VERIFY"
    mobile_otp.style.display = "block";
    phone.style.display = "none"
    document.querySelector("#moileCode").style.display = "none"
    phone_otp_msg = `SMS has been sent to ${phone.value}.Use the OTP to continue registration. `
}

function otpMailVerificationFailed(){
    emailBtn.textContent = "TRY AGAIN"
    emailBtn.style.backgroundColor = "red"
    email_otp_msg.textContent = `OTP verification has failed, try again with a valid email`
}


function otpMobileVerificationFailed(){
    phoneBtn.textContent = "TRY AGAIN"
    phoneBtn.style.backgroundColor = "red"
    phone_otp_msg.textContent = `OTP verification has failed, try again with a valid phone`

}

function otpMailVerificationSuccess(){
    emailBtn.textContent = "VERIFIED"
    emailBtn.style.backgroundColor = "green"
    emailBtn.disabled= true
    email.disabled = true
    email_otp.style.display = "none"
    email.style.display = "block"
    emailBtn.removeEventListener("click",handleEmailBtn)
}


function otpMobileVerificationSuccess(){
    phoneBtn.textContent = "VERIFIED"
    phoneBtn.style.backgroundColor = "green"
    phoneBtn.disabled = true
    phone.disabled = true
    mobile_otp.style.display = "none"
    phone.style.display ="block"
    phone_otp_msg.textContent = "Mobile Number Verified"
    phone_otp_msg.color= "green"
    phoneBtn.removeEventListener("click",handlePhnBtn)
}