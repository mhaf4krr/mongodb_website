var cityList = [];
function getFormData() {
    var agentData = {};
    var agentForm = $("#registerAgent").serializeArray();
    $.each(agentForm, function(i, field) {
        agentData[field.name] = field.value
    });
    return agentData
}
;function getCity() {
    var cityValue = document.getElementById("state").value;
    getCityData(cityList, cityValue)
}
;function getCityData(cityRes, selectedState) {
    var _city = document.getElementById('city');
    var cityData = [];
    cityRes.forEach(function(city) {
        if (city && city.state && selectedState === city.state) {
            cityData.push(city)
        }
    });
    var sortedCityData = cityData.sort(function(a, b) {
        return a.name <= b.name ? -1 : 1
    });
    _city.innerHTML = '<option value="">-- Select City -- </option>';
    sortedCityData.forEach(function(cityName) {
        if (cityName && cityName.name) {
            _city.innerHTML += (`<option value="${cityName.name}">${cityName.name}</option>`)
        }
    })
}
;function getUnique(array) {
    var uniqueArray = [];
    for (i = 0; i < array.length; i++) {
        if (uniqueArray.indexOf(array[i]) === -1) {
            uniqueArray.push(array[i])
        }
    }
    return uniqueArray
}
function getStateData(res) {
    var stateData = [];
    var _state = document.getElementById('state');
    cityList = res.cityInfos || [];
    res.cityInfos.forEach(function(city) {
        if (city && city.state) {
            stateData.push(city.state)
        }
    });
    getCityData(res.cityInfos);
    var commonState = getUnique(stateData);
    var sortedCommonState = commonState.sort();
    _state.innerHTML = '<option value="">-- Select State -- </option>';
    sortedCommonState.forEach(function(stateName) {
        _state.innerHTML += (`<option value="${stateName}">${stateName}</option>`)
    })
}
;function getState() {
    fetch("https://tripjack.com/gms/v1/cities", {"credentials":"include","headers":{"accept":"*/*","accept-language":"en-IN,en-US;q=0.9,en;q=0.8,ur;q=0.7","content-type":"application/json","sec-fetch-dest":"empty","sec-fetch-mode":"cors","sec-fetch-site":"same-origin"},"referrer":"https://tripjack.com/nav/partner_register","referrerPolicy":"no-referrer-when-downgrade","body":"{\"country\":\"India\"}","method":"POST","mode":"cors"})
    .then((res)=> res.json())
    .then((data)=> getStateData(data))
}
