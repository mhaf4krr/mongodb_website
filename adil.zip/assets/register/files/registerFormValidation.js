let registerBtn = document.querySelector("#registerBtn")

$(document).ready(function() {
    $("body").on("click", "input", function(event) {
        var name = $(this).attr("name");
        $("." + name).css("display", "none")
    })
    $("body").on("change", "select", function(event) {
        var name = $(this).attr("name");
        $("." + name).css("display", "none")
    })
    $("body").on("click", "#registerBtn", function(event) {
        function errorScrollTop(className) {
            $('html, body').animate({
                scrollTop: $(className).position().top
            }, 'slow')
        }
        function errorScrollBottom(className) {
            $('html, body').animate({
                scrollTop: $(className).position().bottom
            }, 'slow')
        }
        event.preventDefault();
        var agentData = getFormData();
        var terms = document.getElementById('terms');
        if (agentData.name == "") {
            $(".name").css("display", "block");
            errorScrollTop('.name');
            return !1
        }
        if (agentData.phone !== "" && !mobileCheck(agentData.phone)) {
            $(".phone").css("display", "block");
            errorScrollTop('.phone');
            return !1
        }
        if (!otpVerified.mobile) {
            $(".mobile").css("display", "block");
            errorScrollTop('.mobile');
            return !1
        }
        if (!otpVerified.email) {
            $(".email").css("display", "block");
            errorScrollTop('.email');
            return !1
        }
        if (agentData.password === ' ') {
            $(".password").css("display", "block");
            errorScrollTop('.password');
            return !1
        }
        if (!validPassword(agentData.password)) {
            errorScrollTop('.password');
            return !1
        }
        if (!confirmPassword()) {
            errorScrollTop('.confirm-password');
            return !1
        }
        if (agentData.panName == "") {
            $(".panName").css("display", "block");
            errorScrollTop('.panName');
            return !1
        }
        if (agentData.PAN == "" || !panFormat(agentData.PAN)) {
            $(".PAN").css("display", "block");
            errorScrollTop('.PAN');
            return !1
        }
        if (agentData.inchargeEmail !== '' && !emailCheck(agentData.inchargeEmail)) {
            $(".inchargeEmail").css("display", "block");
            errorScrollTop('.inchargeEmail');
            return !1
        }
        if (agentData.inchargeNumber !== '' && !mobileCheck(agentData.inchargeNumber)) {
            $(".inchargeNumber").css("display", "block");
            errorScrollTop('.inchargeNumber');
            return !1
        }
        if (agentData.gstEmail !== '' && !emailCheck(agentData.gstEmail)) {
            $(".gstEmail").css("display", "block");
            errorScrollBottom('.gstEmail');
            return !1
        }
        if (agentData.gstPhone !== '' && !mobileCheck(agentData.gstPhone)) {
            $(".gstPhone").css("display", "block");
            errorScrollBottom('.gstPhone');
            return !1
        }
        if (agentData.address == "") {
            $(".address").css("display", "block");
            errorScrollBottom('.address');
            return !1
        }
        if (agentData.pincode == "") {
            $(".pincode").css("display", "block");
            return !1
        }
        if (agentData.country == "") {
            $(".country").css("display", "block");
            return !1
        }
        if (agentData.state == "" || agentData.state === "--- Select State ---") {
            $(".state").css("display", "block");
            return !1
        }
        if (agentData.city == "" || agentData.city === "--- Select City ---") {
            $(".city").css("display", "block");
            return !1
        }
        if (!terms.checked) {
            $(".terms").css("display", "block");
            return !1
        }
        getId('registerBtn').classList.add('disabled');
        getId('registerBtn').innerHTML = "<img src='/register/files/loader.svg' class='btnLoader'/>";
        var {name='', email=EMAIL, password='', phone='', mobile=MOBILE, role='', inchargeName='', inchargeEmail='', inchargeNumber='', gstNumber='', gstEmail='', gstPhone='', gstName='', gstAddress='', PAN='', panName='', address='', pincode='', city='', state='', country=''} = agentData;
        finalData = {
            name,
            email,
            password,
            phone,
            mobile,
            role,
            contactPersonInfo: {
                name: inchargeName,
                email: inchargeEmail,
                mobile: inchargeNumber,
            },
            gstInfo: {
                gstNumber,
                gstEmail,
                gstPhone,
                gstName,
                gstAddress
            },
            panInfo: {
                number: PAN,
                panName
            },
            addressInfo: {
                address,
                pincode,
                cityInfo: {
                    name: city,
                    state,
                    country
                }
            }
        }
        var options = {
            method: 'POST',
            body: JSON.stringify(finalData),
            headers: {
                'content-type': 'application/json',
            }
        };
        
        let url = window.location.origin + '/db/register_external_agent'

        registerBtn.disabled = true

        fetch(url, options)
        .then(res => res.text())
        .then(res => { console.log(res)
            let response = res;

            if(response === "SUCCESS") {
                registerBtn.textContent = "SUCCESS"
                registerBtn.style.backgroundColor = "green"
            }

            else {
                registerBtn.textContent = "FAILURE"
                registerBtn.style.backgroundColor = "red";
                setTimeout(()=>{window.location.reload();},300)
            }
        });
       
    })
});
